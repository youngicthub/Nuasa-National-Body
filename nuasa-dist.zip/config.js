/**
 * NUASA runtime configuration
 * Loaded before the React bundle — sets the live Replit API URL.
 * Edit this file on afeeshost to change the backend URL.
 */
window.__NUASA_API_URL__ = "https://nuasa-national-body--everyoungdan200.replit.app/api";
