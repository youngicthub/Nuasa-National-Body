NUASA frontend live upload

1. Upload/extract the CONTENTS of this folder into your hosting document root.
2. Keep config.js in the same folder as index.html.
3. Do not upload the folder itself as a nested directory.
4. The frontend is configured to use:
   https://nuasa-national-body--everyoungdan200.replit.app/api
5. The included .htaccess enables SPA routes on Apache hosting.

This package contains frontend static files only. The API remains on Replit.
